import { GoogleGenAI } from "@google/genai";
import { GenerationOptions } from "../types";
import { analyzeProblemForTikz, getDynamicTikzSnippets } from "../constants";

// Models
const GEMINI_MODEL = 'gemini-3-flash-preview';

// Initialize the API client with the environment variable
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

interface CallConfig {
  prompt: string;
  hasImage?: boolean;
  imageBase64?: string;
  mime?: string;
}

/**
 * Calls Gemini API using the environment key
 */
const callGeminiAPI = async (cfg: CallConfig): Promise<string> => {
  const { prompt, hasImage, imageBase64, mime } = cfg;

  try {
    let response;
    
    if (hasImage && imageBase64) {
       // Multimodal call
       const cleanBase64 = imageBase64.split(',')[1] || imageBase64;
       const mimeType = mime || 'image/jpeg';
       
       response = await ai.models.generateContent({
         model: GEMINI_MODEL,
         contents: {
           parts: [
             { text: prompt },
             {
               inlineData: {
                 mimeType: mimeType,
                 data: cleanBase64
               }
             }
           ]
         }
       });
    } else {
      // Text-only call
      response = await ai.models.generateContent({
        model: GEMINI_MODEL,
        contents: prompt
      });
    }

    const text = response.text;
    if (text) {
      return text;
    }
    throw new Error('Mô hình trả về nội dung rỗng.');

  } catch (e: any) {
    console.error("Gemini API Error:", e);
    // Extracting helpful message if possible
    let errorMessage = e.message || 'Không xác định';
    if (e.message && e.message.includes('404')) {
        errorMessage = 'Model không tìm thấy hoặc chưa được hỗ trợ (404). Vui lòng kiểm tra lại cấu hình model.';
    }
    throw new Error(`Lỗi gọi API: ${errorMessage}`);
  }
};

/**
 * Convert Image to Text with TikZ awareness
 */
export const convertImageToText = async (imageBase64: string): Promise<string> => {
  try {
    const mime = 'image/jpeg';
    
    // 1. Analyze Category
    const analysisPrompt = `Phân tích ảnh và trả về 1 từ khóa: "hinh_phang" / "hinh_khong_gian" / "do_thi" / "bang_bien_thien" / "truc_so" / "bieu_do" / "khong_co_hinh"`;
    
    const categoryRaw = await callGeminiAPI({
      prompt: analysisPrompt,
      hasImage: true,
      imageBase64,
      mime
    });
    
    const category = categoryRaw.trim().toLowerCase();
    const snippets = getDynamicTikzSnippets(category);
    
    // 2. OCR with Snippets
    const conversionPrompt = `Hãy gõ lại CHÍNH XÁC toàn bộ nội dung trong ảnh thành văn bản. Công thức bọc trong dấu $. 
Nếu có hình: chèn code TikZ đúng vị trí. Loại hình: ${category.toUpperCase()}

${snippets ? `%% TIKZ SNIPPETS THAM KHẢO\n${snippets}\n` : ''}

Chỉ trả về nội dung (không thêm giải thích).`;

    return await callGeminiAPI({
      prompt: conversionPrompt,
      hasImage: true,
      imageBase64,
      mime
    });

  } catch (err: any) {
    throw new Error('Lỗi chuyển ảnh: ' + err.message);
  }
};

/**
 * Generate Similar Problems
 */
export const generateSimilarProblems = async (originalProblem: string, options: GenerationOptions): Promise<string> => {
  try {
    const {
      numberOfProblems,
      difficultyLevel,
      problemType,
      includeSolutions,
      subject
    } = options;

    const tikzCategory = analyzeProblemForTikz(originalProblem);
    const dynamicSnippets = getDynamicTikzSnippets(tikzCategory, originalProblem);

    const prompt = `Bạn là chuyên gia biên soạn đề ${subject}. Tạo ${numberOfProblems} bài tương tự, đổi số liệu hợp lý.
Độ khó: ${difficultyLevel}. Dạng: ${problemType}. Kèm lời giải: ${includeSolutions ? 'CÓ' : 'KHÔNG'}.

====== ĐỀ GỐC ======
${originalProblem}
====================

${dynamicSnippets ? `%% TikZ snippets gợi ý (nếu cần vẽ):\n${dynamicSnippets}\n` : ''}

YÊU CẦU:
- Mỗi bài: nêu đề, (nếu có) block \\begin{tikzpicture}...\\end{tikzpicture} ngay sau đề, rồi 4 phương án A, B, C, D.
- Công thức dùng LaTeX (bọc $...$). 
- Nếu includeSolutions=CÓ thì thêm **Lời giải** dưới mỗi bài.
- KHÔNG dùng markdown header (###), chỉ dùng text thuần hoặc LaTeX.

TRẢ VỀ đúng format trên cho toàn bộ ${numberOfProblems} bài.`;

    return await callGeminiAPI({
      prompt,
      hasImage: false
    });
  } catch (err: any) {
    throw new Error('Lỗi tạo bài: ' + err.message);
  }
};

/**
 * Solve Original Problem
 */
export const solveOriginalProblem = async (originalProblem: string): Promise<string> => {
  const prompt = `Giải bài sau theo format ngắn gọn (không liệt kê "Bước 1; Bước 2; ..."):
- Chỉ ghi **Đề bài:** rồi **Lời giải:** (dùng LaTeX trong $...$), cuối cùng **Đáp án:**.
- Nếu có hình (TikZ), chỉ mô tả ngắn trong lời giải (không bắt buộc vẽ lại).
- Môn: toán, mức độ: chi tiết, giải thích: Có.

**Đề bài:**
${originalProblem}

Hãy trả đúng format: 
Đề bài: ...
Lời giải: ...
Đáp án: ...`;

  return await callGeminiAPI({
    prompt,
    hasImage: false
  });
};

/**
 * Convert to LaTeX (Ex_Test format)
 */
export const convertToLatex = async (content: string, includeSolutions: boolean): Promise<string> => {
  const prompt = `Chuyển nội dung sau sang LaTeX môi trường \\begin{ex} ... \\end{ex}.
Giữ nguyên block TikZ nếu có. Phần lựa chọn đưa vào \\choice{...}{...}{...}{...}.
Nếu có "Lời giải:", chuyển sang \\loigiai{...} khi includeSolutions = ${includeSolutions ? 'CÓ' : 'KHÔNG'}.

------ NỘI DUNG ------
${content}
----------------------

TRẢ VỀ: mã LaTeX hoàn chỉnh theo ex_test.`;

  return await callGeminiAPI({
    prompt,
    hasImage: false
  });
};